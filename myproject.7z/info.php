<?php
 echo"yek"
 ?>